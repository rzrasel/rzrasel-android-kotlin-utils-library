package com.apphiveme.banglaenglishsmartwordbook.model

import java.io.Serializable;

data class IntentDataModel(
    var dataModel: Any?,
): Serializable
