# Rz Rasel Kotlin Utils
rzrasel-kotlin-utils

### Rz Rasel Kotlin Library Utils

### GIT Command
```git_command
git init
git remote add origin https://github.com/rzrasel/rzrasel-kotlin-utils.git
git remote -v
git fetch && git checkout master
git add .
git commit -m "Add Readme & Git Commit File"
git pull
git push --all
git status
git remote show origin
git status

git rm -rf .idea;
git commit -m "delete .idea";
git push;
```