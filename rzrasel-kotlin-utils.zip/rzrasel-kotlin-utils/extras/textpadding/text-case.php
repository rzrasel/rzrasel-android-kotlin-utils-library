<?php
abstract class TextCase {
    const AlikeCase = 0;
    const UpperCase = 1;
    const LowerCase = 2;
    const UcWordsCase = 3;
    const UcFirstCase = 4;
}
?>